(function(){
    window.onload = function(){
        window.Vue.createApp({
            data() {
                return {
                    message: 'Hello Vue!',
                    vScore: null,
                    attractions: []
                }
            },
            mounted() {
                // methods can be called in lifecycle hooks, or other methods!
                //this.vScore = ;
            },
            methods: {
                onChangeVscore(event) {
                    axios
                        .get(`/attractions/search?score=${parseInt(event.target.value)}`)
                        .then(response => {
                            console.log(response);
                            this.attractions = response.data;
                        })
                }
            },
            created() {
                axios
                    .get(`/attractions/all`)
                    .then(response => {
                        console.log(response);
                        this.attractions = response.data;
                    })
            },
        }).mount('#app')
    };

}());